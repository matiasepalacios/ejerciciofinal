package com.matiaspalacios.trabajofinal.classes;

public final class Configuration {
	
	public final static String _ID = "id";
	public final static String ATTRIBUTE = "attribute";
	public final static String VALUE = "value";

}
