package com.matiaspalacios.trabajofinal.classes;

public class Constants {

	public static final String BROADCAST_ACTION = "BROADCAST";
	
	public static final String EXTENDED_DATA_STATUS = "STATUS";
	
}
