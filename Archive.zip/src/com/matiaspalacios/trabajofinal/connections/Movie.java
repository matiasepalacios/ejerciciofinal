package com.matiaspalacios.trabajofinal.connections;

public class Movie extends RottenTomatoesAPI {

}
