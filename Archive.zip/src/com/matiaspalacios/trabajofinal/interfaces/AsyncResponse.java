package com.matiaspalacios.trabajofinal.interfaces;

import android.database.MatrixCursor;

public interface AsyncResponse {
	
	void processFinish(MatrixCursor result);

}
