/** Automatically generated file. DO NOT MODIFY */
package com.matiaspalacios.trabajofinal;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}